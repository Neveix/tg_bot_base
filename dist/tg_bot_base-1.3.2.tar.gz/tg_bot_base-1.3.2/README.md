# tg_bot_base
python library, useful for creating simple bots