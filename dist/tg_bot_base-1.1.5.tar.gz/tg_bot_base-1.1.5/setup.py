from setuptools import setup # type: ignore

setup(
   name='tg_bot_base',
   version='1.1.5',
   description='It is useful for creating simple telegram bots',
   author='Neveix',
   author_email='neveix2003@mail.ru',
   packages=['tg_bot_base'],
   install_requires=['python-telegram-bot']
)
